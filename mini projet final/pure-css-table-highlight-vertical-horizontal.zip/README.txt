A Pen created at CodePen.io. You can find this one at http://codepen.io/alexerlandsson/pen/mPWgpO.

 A simple (and nasty) trick to have vertical and horizontal highlight on hover on tables made with pure CSS.